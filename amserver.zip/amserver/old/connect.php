<?php
function getConnection()
{
	$host = "192.168.100.122";
	$user = "root";
	$pass = "secret";
	$link = mysqli_connect($host, $user, $pass, "amserver");

	if (!$link) {
	    return false;
	}
	return $link;
}
?>