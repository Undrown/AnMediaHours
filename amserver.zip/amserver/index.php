<?php
if (!$_GET['action']) {
	die('Hello at AMServer');
}
switch ($_GET['action']) {
	case 'debug':
		include 'include/test.php';
		break;
	case 'login':
		include 'include/login.php';
		break;
	case 'useradd':
		include 'include/useradd.php';
		break;
	case 'userdel':
		include 'include/userdel.php';
		break;
	case 'add_entry':
		include 'include/add_entry.php';
		break;
	case 'get_data':
		include 'include/get_data.php';
		break;
	default:
		die('ERROR_INVALID_ACTION');
		break;
}
?>