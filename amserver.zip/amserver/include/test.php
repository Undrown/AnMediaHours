<?php
require 'functions.php';
//reset_db();
//echo useradd(222, 'VEN', 150);
//echo useradd(123, '���', 150);
echo '<pre>';
print_r(get_users());
echo "\n";
print_r(login(123));
$id = login(123)['id'];
echo "\n";
echo add_entry($id, 0, 1);
echo "\n";
print_r(get_data($id));
echo '</pre>';
?>